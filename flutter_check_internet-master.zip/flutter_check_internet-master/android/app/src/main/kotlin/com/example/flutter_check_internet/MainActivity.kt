package com.example.flutter_check_internet

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
